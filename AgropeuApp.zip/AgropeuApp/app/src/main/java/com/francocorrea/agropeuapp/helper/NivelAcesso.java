package com.francocorrea.agropeuapp.helper;

public class NivelAcesso {


    public static String NIVEL_01 = "1";
    public static String NIVEL_02 = "2";
    public static String NIVEL_025 = "2.5";
    public static String NIVEL_03 = "3";
    public static String NIVEL_04 = "4";
    public static String NIVEL_10 = "10";

}
