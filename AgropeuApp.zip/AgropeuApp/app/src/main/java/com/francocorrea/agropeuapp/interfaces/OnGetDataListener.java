package com.francocorrea.agropeuapp.interfaces;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;

public interface OnGetDataListener {
    public void onStart();
    public void onSuccess(DataSnapshot data, int convidadosPresentes, int inativos);
    public void onFailed(DatabaseError databaseError);
}